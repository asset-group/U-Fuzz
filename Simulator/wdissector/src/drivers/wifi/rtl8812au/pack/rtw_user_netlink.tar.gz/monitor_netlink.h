#ifndef __MONITOR_NETLINK__
#define __MONITOR_NETLINK__

#include <linux/types.h>
#include <net/netlink.h>
#include <linux/netlink.h>
#include <net/net_namespace.h>

/*
 * Netlink functions.
 */

// Netlink server definitions

#define RTW_NETLINK_LOG_TAG "RTW Netlink: INFO "
#define RTW_NETLINK_USER_FAMILY 25      // Netlink port
#define RTW_NETLINK_PID 1               // PID for unicast
#define RTW_NETLINK_GROUP 1             // PID for multicast
#define RTW_NETLINK_GFP_FLAG GFP_ATOMIC // NETLINK Non block IO flag
#define RTW_DIR_TX 0
#define RTW_DIR_RX 1

// Commands received from user space
#define RTW_NETLINK_CMD_READ_ADDR 0
#define RTW_NETLINK_CMD_WRITE_ADDR 1
#define RTW_NETLINK_CMD_MULTIWRITE_ADDR 2
#define RTW_NETLINK_CMD_MULTIREAD_ADDR 3
#define RTW_NETLINK_CMD_INTERRUPT_RX_ENABLE 4
#define RTW_NETLINK_CMD_FORCE_FLAGS_ENABLE 5
#define RTW_NETLINK_CMD_FORCE_FLAGS_RETRY 6
#define RTW_NETLINK_CMD_SEND_DATA_TX 7

// Commands sent to user space
#define RTW_NETLINK_CMD_TX 8
#define RTW_NETLINK_CMD_RX 9

#define RTW_NETLINK_STATUS_OK 0
#define RTW_NETLINK_STATUS_FAIL -1

#define NLOG(...) (printk(KERN_INFO RTW_NETLINK_LOG_TAG "%s\n", __VA_ARGS__))
#define NLOGX(fmt, ...) (printk(KERN_INFO RTW_NETLINK_LOG_TAG fmt "\n", __VA_ARGS__))

// Prototypes
int nl_server_init(void);
int nl_server_deinit(void);
int nl_server_send_data(uint8_t dir, void *msg, u16 msg_size);
static inline int nl_server_send_reply(void *msg, u8 msg_size);

#endif