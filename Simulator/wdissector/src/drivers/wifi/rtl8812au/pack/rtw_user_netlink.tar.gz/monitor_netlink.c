#include <monitor_netlink.h>

static u8 nl_server_interrupt_rx_enable = 0;
static u8 nl_server_initialized = 0;
static struct sock *nl_sk = NULL; // Netlink socket

// Receive command or data from user-space
static void nl_server_handle_rcv(struct sk_buff *skb)
{
    u8 netlink_command;
    u32 *addr_requested;
    u32 *addr_value;
    u8 addr_value_size;
    u32 reg_val;
    int res;
    // struct data_queue *queue = NULL;
    // struct ieee80211_tx_control control = {};
    struct sk_buff *s;

    netlink_command = skb->data[0];

    switch (netlink_command)
    {
    case RTW_NETLINK_CMD_INTERRUPT_RX_ENABLE:
        if (skb->len < 2)
            return;
        nl_server_interrupt_rx_enable = skb->data[1];
        res = RTW_NETLINK_STATUS_OK;
        nl_server_send_reply(&res, sizeof(res));
        NLOGX("RX interrupt set to %d", nl_server_interrupt_rx_enable);
        break;
    }
    // NLOGX("SKB Received, len:%d", skb->len);
}

// Send data packets to user-space using netlink
int nl_server_send_data(uint8_t dir, void *msg, u16 msg_size)
{
    struct sk_buff *skb_out;
    int res;

    if (!nl_server_initialized || !nl_server_interrupt_rx_enable)
        return -1;

    if (msg_size > 2048)
    {
        NLOG("Message size over 2048 bytes");
        return 0; // prevent packages higher than 2048 bytes
    }

    skb_out = nlmsg_new(msg_size, RTW_NETLINK_GFP_FLAG); // Allocate skb with msg_size
    if (!skb_out)
        return 0;

    nlmsg_put(skb_out, RTW_NETLINK_USER_FAMILY, 0, NLMSG_DONE, msg_size + 1, 0);      // Put netlink protocol data in skb
    skb_out->data[0] = (dir == RTW_DIR_TX ? RTW_NETLINK_CMD_TX : RTW_NETLINK_CMD_RX); // Add TX/RX direction command
    memcpy(skb_out->data + 1, (u8 *)msg, msg_size);                                   // Copy msg to skb (ignoring netlink data offset)
    skb_out->len = msg_size;                                                          // Set skb length (ignoring netlink size)
    //printk("len:%d, data:%02x\n", skb_out->len, ((u8 *)skb_out->data)[0]);
    res = nlmsg_multicast(nl_sk, skb_out, RTW_NETLINK_USER_FAMILY, RTW_NETLINK_GROUP, RTW_NETLINK_GFP_FLAG);

    if (res < 0)
    {
        nl_server_interrupt_rx_enable = 0;
        NLOG("Client disconnected");
        return res;
    }
    return msg_size;
}

// Server reply
static inline int nl_server_send_reply(void *msg, u8 msg_size)
{
    struct sk_buff *skb_out;
    int res;

    if (msg_size > 176)                                  // Raw netlink messages don't work for more than 176 bytes
        return -1;                                       // prevent packages higher than 2048 bytes
    skb_out = nlmsg_new(msg_size, RTW_NETLINK_GFP_FLAG); // Allocate skb with msg_size
    if (!skb_out)
        return -1;

    memcpy(skb_out->data, (u8 *)msg, msg_size); //Copy msg to skb
    skb_out->len = msg_size;                    //Configure skb size

    res = nlmsg_multicast(nl_sk, skb_out, RTW_NETLINK_USER_FAMILY, RTW_NETLINK_GROUP, RTW_NETLINK_GFP_FLAG);

    if (res < 0)
        return -1;

    return msg_size;
}

int nl_server_init(void)
{
    int ret;
    struct netlink_kernel_cfg cfg = {
        .input = nl_server_handle_rcv,
    };

    if (!nl_sk && !nl_server_initialized)
    {

        NLOG("Netlink Service started");

        nl_sk = netlink_kernel_create(&init_net, RTW_NETLINK_USER_FAMILY, &cfg);

        if (nl_sk == NULL)
        {
            nl_server_initialized = 0;
            printk(KERN_ERR RTW_NETLINK_LOG_TAG "Error creating socket.\n");
            return -1;
        }

        nl_server_initialized = 1;
        return 0;
    }
    else
    {
        printk(KERN_ERR RTW_NETLINK_LOG_TAG "Netlink service already started or port %d busy\n", RTW_NETLINK_USER_FAMILY);
    }
    return -1;
}

int nl_server_deinit(void)
{
    if (nl_sk)
    {
        nl_server_initialized = 0;
        netlink_kernel_release(nl_sk);
        nl_sk = NULL;
        NLOG("Netlink Service stopped");

        return 0;
    }
    else
    {
        printk(KERN_ERR RTW_NETLINK_LOG_TAG "Netlink service not started on port %d\n", RTW_NETLINK_USER_FAMILY);
    }

    return -1;
}